
Change your password <a href="http://localhost:3000/reset/{{$token}}"> here</a>
