
Change your password <a href="http://localhost:3000/reset/<?php echo e($token); ?>"> here</a>
<?php /**PATH D:\GDPS\gestionproyectos\laravel-api\resources\views/Mails/forgot.blade.php ENDPATH**/ ?>